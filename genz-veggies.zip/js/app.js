/**
 * GenZ Veggies - Core Application Engine
 * Manages Cart, Global Navigation, State Synchronization, Search/Filter, Reviews & Checkout
 */

// Initial Sample Cart if none exists in localStorage
const INITIAL_CART = [
  {
    id: 'spinach-1',
    name: 'Organic Spinach',
    price: 150,
    unit: 'kg',
    qty: 2,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDvNKEZQOIS6abyKp3GYMBb-U8nW5AHXAoPspvVKp_TczJKzEKYVxazPX14v3gUJQotFQvYwI8dKNPYwjK9Z7-etOK8N5mkcAxleUd881EC3ijX2mgtUlCgq5L-tg6M01gkGsL_irt0njg4gyr_68jxaDEXyDbzwb5ml0WBhjz_oeVodLSZ7Ws1bIAm58dyWfepx3qQt-xPqgQy_8Yf8DmgGmRJaquVnShSfk4B3GNRVrJ0LN0KUqro'
  },
  {
    id: 'tomato-2',
    name: 'Fresh Tomatoes',
    price: 80,
    unit: 'kg',
    qty: 1,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDe37WD6YSlie_2JkOBl4UeS117fCtrBiD07nheDUtHfiVMMthVylLJbmO92N-0uI37vDl-Z_d8zXY_kUc-erpKL_sKp5Trln_SpsuSArT2H82cLLtcA3YBazU-ZT2lk63Orc44enpXoklqqqoPbriMQ6a6eu1XS5-QKJ-OehHXwKrqqHDmO3kk4IhOSZf1jXpw-2cTK0hWF71Dtqf13WivU0UYD-zepf7MxveW9NDeaH53C3nkQhNA'
  }
];

const STORAGE_KEY_CART = 'genz_veggies_cart';
const STORAGE_KEY_REVIEWS = 'genz_veggies_reviews';

// --- Cart Management Functions ---
function getCart() {
  const data = localStorage.getItem(STORAGE_KEY_CART);
  if (!data) {
    localStorage.setItem(STORAGE_KEY_CART, JSON.stringify(INITIAL_CART));
    return [...INITIAL_CART];
  }
  try {
    return JSON.parse(data) || [];
  } catch (e) {
    return [];
  }
}

function saveCart(cart) {
  localStorage.setItem(STORAGE_KEY_CART, JSON.stringify(cart));
  updateCartBadges();
}

function addToCart(product, qty = 1) {
  const cart = getCart();
  const existing = cart.find(item => item.id === product.id);
  if (existing) {
    existing.qty += qty;
  } else {
    cart.push({
      id: product.id,
      name: product.name,
      price: Number(product.price),
      unit: product.unit || 'kg',
      image: product.image,
      qty: qty
    });
  }
  saveCart(cart);
  showToast(`Added ${qty}x ${product.name} to cart!`);
}

function updateCartItemQty(id, newQty) {
  let cart = getCart();
  if (newQty <= 0) {
    cart = cart.filter(item => item.id !== id);
  } else {
    const item = cart.find(item => item.id === id);
    if (item) {
      item.qty = newQty;
    }
  }
  saveCart(cart);
}

function removeCartItem(id) {
  let cart = getCart();
  const item = cart.find(i => i.id === id);
  cart = cart.filter(i => i.id !== id);
  saveCart(cart);
  if (item) {
    showToast(`Removed ${item.name} from cart`);
  }
}

function clearCart() {
  localStorage.setItem(STORAGE_KEY_CART, JSON.stringify([]));
  updateCartBadges();
}

function getCartCount() {
  const cart = getCart();
  return cart.reduce((sum, item) => sum + item.qty, 0);
}

function getCartSubtotal() {
  const cart = getCart();
  return cart.reduce((sum, item) => sum + (item.price * item.qty), 0);
}

// Update Cart Badge Across Header and Floating Action Button
function updateCartBadges() {
  const count = getCartCount();
  const subtotal = getCartSubtotal();

  // Badges in desktop/mobile nav
  document.querySelectorAll('.nav-cart-count, #nav-cart-count, #cart-count').forEach(el => {
    el.textContent = count;
    if (count > 0) {
      el.classList.remove('hidden');
      el.classList.add('scale-125');
      setTimeout(() => el.classList.remove('scale-125'), 200);
    } else {
      el.classList.add('hidden');
    }
  });

  // Floating Cart Button
  const floatBtn = document.getElementById('floating-cart');
  const floatSubtotal = document.getElementById('float-subtotal');
  if (floatBtn && floatSubtotal) {
    if (count > 0) {
      floatBtn.classList.remove('hidden');
      floatSubtotal.textContent = `Rs. ${subtotal}`;
    } else {
      floatBtn.classList.add('hidden');
    }
  }

  // Trigger page-specific cart re-render if on checkout page
  if (typeof renderCheckoutCart === 'function') {
    renderCheckoutCart();
  }
}

// --- Toast Notification System ---
function showToast(message, icon = 'check_circle') {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = 'toast-item';
  toast.innerHTML = `
    <span class="material-symbols-outlined text-green-400" style="font-size: 20px; font-variation-settings: 'FILL' 1;">${icon}</span>
    <span>${message}</span>
  `;

  container.appendChild(toast);

  // Trigger entry
  requestAnimationFrame(() => {
    toast.classList.add('active');
  });

  // Remove after 3.2s
  setTimeout(() => {
    toast.classList.remove('active');
    setTimeout(() => toast.remove(), 350);
  }, 3200);
}

// --- Mobile Navigation Setup ---
function setupMobileNav() {
  const menuBtn = document.getElementById('mobile-menu-btn');
  const closeBtn = document.getElementById('mobile-menu-close');
  const mobileMenu = document.getElementById('mobile-menu');
  const mobileOverlay = document.getElementById('mobile-menu-overlay');

  if (menuBtn && mobileMenu) {
    menuBtn.addEventListener('click', () => {
      mobileMenu.classList.remove('hidden-drawer');
      mobileMenu.classList.add('active-drawer');
      if (mobileOverlay) mobileOverlay.classList.remove('hidden');
      document.body.style.overflow = 'hidden';
    });
  }

  const closeDrawer = () => {
    if (mobileMenu) {
      mobileMenu.classList.remove('active-drawer');
      mobileMenu.classList.add('hidden-drawer');
    }
    if (mobileOverlay) mobileOverlay.classList.add('hidden');
    document.body.style.overflow = '';
  };

  if (closeBtn) closeBtn.addEventListener('click', closeDrawer);
  if (mobileOverlay) mobileOverlay.addEventListener('click', closeDrawer);
}

// --- Accordion Logic for FAQ ---
function toggleAccordion(triggerEl) {
  const item = triggerEl.closest('.accordion-item');
  if (!item) return;

  const isActive = item.classList.contains('active');

  // Close all other accordions
  document.querySelectorAll('.accordion-item').forEach(other => {
    if (other !== item) {
      other.classList.remove('active');
    }
  });

  if (isActive) {
    item.classList.remove('active');
  } else {
    item.classList.add('active');
  }
}

// --- Star Rating Interaction for Write Review ---
let currentRating = 5;
function setRating(val) {
  currentRating = val;
  const ratingInput = document.getElementById('rating-value');
  if (ratingInput) ratingInput.value = val;

  const starContainer = document.getElementById('star-rating');
  if (!starContainer) return;

  const stars = starContainer.querySelectorAll('span');
  stars.forEach((star, index) => {
    if (index < val) {
      star.style.fontVariationSettings = "'FILL' 1";
      star.classList.add('text-amber-500');
      star.classList.remove('text-stone-300');
    } else {
      star.style.fontVariationSettings = "'FILL' 0";
      star.classList.remove('text-amber-500');
      star.classList.add('text-stone-300');
    }
  });
}

// Initialize on DOMContentLoaded
document.addEventListener('DOMContentLoaded', () => {
  updateCartBadges();
  setupMobileNav();

  // Highlight active page link in navigation
  const currentPath = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('nav a, #mobile-menu a').forEach(link => {
    const href = link.getAttribute('href');
    if (href && (href === currentPath || (currentPath === '' && href === 'index.html') || (currentPath === '/' && href === 'index.html'))) {
      if (link.dataset.navlink) {
        link.classList.add('text-primary', 'font-semibold', 'border-b-2', 'border-primary');
        link.classList.remove('text-on-surface-variant');
      }
    }
  });
});
